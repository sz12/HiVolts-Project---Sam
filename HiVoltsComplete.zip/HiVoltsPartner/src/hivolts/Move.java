package hivolts;

public class Move {
	public Coordinate origin;
	public Coordinate move;
	public Move(){
		origin = new Coordinate(0,0);
		move = new Coordinate(0,0);
	}
	public Move(Coordinate a, Coordinate b){
		origin = a;
		move = b;
	}
}