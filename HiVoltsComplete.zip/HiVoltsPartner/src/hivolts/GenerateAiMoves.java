package hivolts;

import java.util.ArrayList;

public class GenerateAiMoves 
{
	private static ArrayList<Move> retval = new ArrayList<Move>();
	private static ArrayList<Coordinate> movedTo = new ArrayList<Coordinate>();
	private static ArrayList<Coordinate> movedAway = new ArrayList<Coordinate>();
	private static Type[][] baord;
	private static byte difficulty;
	private static Coordinate storePlayer;

	public static Move[] genrateMoves(Type[][] a, byte b) {
		retval = new ArrayList<Move>(); //rests all the stuff
		movedTo = new ArrayList<Coordinate>(); //antoher reset
		movedAway = new ArrayList<Coordinate>();
		baord = a; //stores a globally
		difficulty = b; //applys difficulty
		storePlayer = null;

		if (isPlayerLegit()) {
			for (int i = 0; i < baord.length; i++) {
				for (int j = 0; j < baord.length; j++) {//iterate through all them things
					if (baord[i][j].compare('M') && !inMovedAway(new Coordinate(i, j)) && !inMovedTo(new Coordinate(i, j))) { //if its a moho great as long as it hasnt moveed or mbeen moved too
						Move(new Coordinate(i, j));
					}
				}
			}
		}
		Move[] finalRetval = new Move[retval.size()];
		finalRetval = retval.toArray(finalRetval); //kinda sketchy way i dont really understand of converting
		return finalRetval;
	}

	private static void Move(Coordinate a) {
		//basic structure
		//check one if false go to next
		//if none just add to both moved and moved away
		if (difficulty == 0) {//if its normal
			if (forcedOrthognalMove(a)) {
			} //the method's actually moves it too
			else if (diagonalMove(a, false)) {
			} else if (orthagnalMove(a, false)) {
			} else if (diagonalMove(a, true)) {
			} else if (orthagnalMove(a, true)) {
			} else {
				movedTo.add(a);//basically set this sqaure to moved
				movedAway.add(a);
			}
		} else if (difficulty == 1) { //hard
			if (forcedOrthognalMove(a)) {
			} //the method's actually moves it too
			else if (diagonalMove(a, false)) {
			} else if (orthagnalMove(a, false)) {
			}
			//else if(diagonalMove(a, true)){} same sequnce but dont die unless forced
			//else if(orthagnalMove(a, true)){} 
			else {
				movedTo.add(a);//basically set this sqaure to moved
				movedAway.add(a);
			}
		} else if (difficulty == 2) { //ulimate level
			if (forcedOrthognalMove(a)) {
			} //the method's actually moves it too
			else if (diagonalMove(a, false)) {
			} else if (orthagnalMove(a, false)) {
			}
			//else if(diagonalMove(a, true)){} same sequnce but dont die unless forced
			//else if(orthagnalMove(a, true)){} 
			else if (sneakyMove(a)) {
			} //added sneaky move thate trys to get closer
			else {
				movedTo.add(a);//basically set this sqaure to moved
				movedAway.add(a);
			}
		}
	}

	private static boolean forcedOrthognalMove(Coordinate a) {
		//checks if its actually orthogonal to the player
		if (playerLoc().x == a.x ^ playerLoc().y == a.y) { //Exclusive-or so that if its right on top it doesn't have to do all this
			//Variable for storing the closest direction
			Coordinate closer = new Coordinate(0, 0); //default value just in case none of the setters evaluate true
			//finds the right direction
			if (playerLoc().x > a.x) { //the player is to the right of a
				//Generate a point that more right and assign to closer
				closer = new Coordinate(a.x + 1, a.y); //no need to change y coordinate, previous checks have shown that it is orthogonal on one axis
			} else if (playerLoc().x < a.x) {//the player is to the left of a
				//Generate a point more left and assign to closer
				closer = new Coordinate(a.x - 1, a.y); //just one step closer
			} else if (playerLoc().y > a.y) {//the player is higher than a
				//Generate a higher point and assign to closer
				closer = new Coordinate(a.x, a.y + 1); //this time changing y coordinate instead
			} else if (playerLoc().y < a.y) {//the player is lower than a
				//Generate a lower point and assign to closer
				closer = new Coordinate(a.x, a.y - 1); //simply one spot closer to the player
			}
			//makes a 100% forced move in that direction
			forcedMoveBetween(a, closer);
			//returns true
			return true; //its making a move, so it effectively notifies the caller it is
		}
		return false;
	}

	private static void forcedMoveBetween(Coordinate origin, Coordinate target) { //makes a move from origin to target, 100% forced
		//basic flow:
		//check if the place if moving too is a mho
		//if it hasn't moved move it first
		//move this one now,
		//if its a mho just add this to moved away and add a move to moves
		//if if its a fence, just add to moves and add the current type to moved away
		//if its a tile/player check if its moved to and then add to moved and add approtatie movedto and away

		//check if the target is a mho, doesn't need to check if its been moved, because then it has to annihilate it, as the move is forced
		if (baord[target.x][target.y].compare('M') && !inMovedAway(target)) { //also checking to make sure it hasn't been moved away from
			//the code here should only be running if there is an unmoved mho on "target"
			Move(target); //move target first
			forcedMoveBetween(origin, target); //move this one again
		} else if (inMovedTo(target)) { //target has already been moved too
			//the single check above assures that there is a mho in the way, and it has already moved
			//add the orgin to moved away
			movedAway.add(origin);
			//the place its moving too has already been moved to, so dont need to add it to moved to again
			//add this move to retval
			retval.add(new Move(origin, target));
		} else {//normal place to move too, has to be a fence, player of tile
				//already checked if its been moved to already, so this hasn't been moved to
				//it doesn't matter if its a fence versus good place to move; the same thing will happen
				//handing moving onto a fence is handled by the moves to board converter
				//this space moves away
			movedAway.add(origin);
			//target gets moved to
			movedTo.add(target);
			//add this move to retval
			retval.add(new Move(origin, target));
		}
	}

	private static boolean diagonalMove(Coordinate a, Boolean shouldSucide) {
		//first check if there actally diagnal
		if (Math.abs(a.x - playerLoc().x) == Math.abs(a.y - playerLoc().y)) { //the distance between the points x should be equal to the distance y, same as slope 1 or -1
			//create a point one step closer
			Coordinate closer = new Coordinate(0, 0); //give it a default value just in case none of the if statements evaluate true
			if (playerLoc().x > a.x && playerLoc().y > a.y) { //the player is to the right and higher
				//Generate a point one step closer, diagonally
				closer = new Coordinate(a.x + 1, a.y + 1);
			} else if (playerLoc().x > a.x && playerLoc().y < a.y) { //the player is further to the right and lower
				//Generate a point one step closer, diagonally
				closer = new Coordinate(a.x + 1, a.y - 1);
			} else if (playerLoc().x < a.x && playerLoc().y < a.y) { //the player is further left and lower
				//Generate a point one step closer, diagonally
				closer = new Coordinate(a.x - 1, a.y - 1);
			}
			//final check instead of else if, just to check for error, that way i get and error value of 0,0
			else if (playerLoc().x < a.x && playerLoc().y > a.y) { //the player is further left and higher
				//Generate a point one step closer, diagonally
				closer = new Coordinate(a.x - 1, a.y + 1);
			}
			return normalMove(a, closer, shouldSucide);
		}
		//diagonal move
		return false;
	}

	private static boolean orthagnalMove(Coordinate a, Boolean shouldSucide) {
		//check if its actally not daignal
		if (!(Math.abs(a.x - playerLoc().x) == Math.abs(a.y - playerLoc().y))) { //check that its not diagonal
			//creat a varible to store one step closer
			Coordinate closer = new Coordinate(0, 0); //give defualt value incase non if statemets evulwate true

			int xDif = Math.abs(a.x - playerLoc().x); //distance between x's
			int yDif = Math.abs(a.y - playerLoc().y); //distance between y's

			if (xDif > yDif) { //distance in x's is greater than distnce of y's
				//moving horizontaly
				if (playerLoc().x > a.x) { //player is further right
					//genrate a point one step closer
					closer = new Coordinate(a.x + 1, a.y);
				} else if (playerLoc().x < a.x) {
					//genrate a point one step closer
					closer = new Coordinate(a.x - 1, a.y);
				}
			} else if (xDif < yDif) { //distance in y's is greater than distance of x'x
				//moveing virtically
				if (playerLoc().y > a.y) { //player is higher
					//genrate a point one step closer
					closer = new Coordinate(a.x, a.y + 1);
				} else if (playerLoc().y < a.y) { //player is lower
					//gernate a point one step closer
					closer = new Coordinate(a.x, a.y - 1);
				}
			}

			//fianlly return trying to make the move
			return normalMove(a, closer, shouldSucide);
		}
		//if its not diagnal return false
		return false;
	}

	private static boolean sneakyMove(Coordinate a) {

		int xDif = Math.abs(a.x - playerLoc().x); //distance between x's
		int yDif = Math.abs(a.y - playerLoc().y); //distance between y's
		if (playerLoc().x > a.x && playerLoc().y > a.y) { //the player is to the right and higher
			if (xDif > yDif) { //x move is prefered
				if (normalMove(a, new Coordinate(a.x + 1, a.y), false)) {
					return true;
				} //if its moves return true
				else if (normalMove(a, new Coordinate(a.x, a.y + 1), false)) {
					return true;
				} //x is prefred but also try a y move
			} else if (xDif < yDif) { //y move is prefred
				if (normalMove(a, new Coordinate(a.x, a.y + 1), false)) {
					return true;
				} //try y move, return true if it moves
				else if (normalMove(a, new Coordinate(a.x + 1, a.y), false)) {
					return true;
				} //y is prefred but also try x
			}
		} else if (playerLoc().x > a.x && playerLoc().y < a.y) { //the player is further to the right and lower
			if (xDif > yDif) { //x move is prefered
				if (normalMove(a, new Coordinate(a.x + 1, a.y), false)) {
					return true;
				} //if its moves return true
				else if (normalMove(a, new Coordinate(a.x, a.y - 1), false)) {
					return true;
				} //x is prefred but also try a y move
			} else if (xDif < yDif) { //y move is prefred
				if (normalMove(a, new Coordinate(a.x, a.y - 1), false)) {
					return true;
				} //try y move, return true if it moves
				else if (normalMove(a, new Coordinate(a.x + 1, a.y), false)) {
					return true;
				} //y is prefred but also try x
			}
		} else if (playerLoc().x < a.x && playerLoc().y < a.y) { //the player is further left and lower
			if (xDif > yDif) { //x move is prefered
				if (normalMove(a, new Coordinate(a.x - 1, a.y), false)) {
					return true;
				} //if its moves return true
				else if (normalMove(a, new Coordinate(a.x, a.y - 1), false)) {
					return true;
				} //x is prefred but also try a y move
			} else if (xDif < yDif) { //y move is prefred
				if (normalMove(a, new Coordinate(a.x, a.y - 1), false)) {
					return true;
				} //try y move, return true if it moves
				else if (normalMove(a, new Coordinate(a.x - 1, a.y), false)) {
					return true;
				} //y is prefred but also try x
			}
		}
		//final check instead of else if, just to check for error, that way i get and error value of 0,0
		else if (playerLoc().x < a.x && playerLoc().y > a.y) { //the player is further left and higher
			if (xDif > yDif) { //x move is prefered
				if (normalMove(a, new Coordinate(a.x - 1, a.y), false)) {
					return true;
				} //if its moves return true
				else if (normalMove(a, new Coordinate(a.x, a.y + 1), false)) {
					return true;
				} //x is prefred but also try a y move
			} else if (xDif < yDif) { //y move is prefred
				if (normalMove(a, new Coordinate(a.x, a.y + 1), false)) {
					return true;
				} //try y move, return true if it moves
				else if (normalMove(a, new Coordinate(a.x - 1, a.y), false)) {
					return true;
				} //y is prefred but also try x
			}
		}
		//if none of these works
		return false;
	}

	private static boolean normalMove(Coordinate origin, Coordinate target, boolean sucide) {
		//first check if the origin is actually a mho
		//if(!(baord[origin.x][origin.y].compare('M') && !inMovedAway(origin))){ //checks if not( origin is a mho and not moved )
		//if the mho isnt there or has moved away
		//	return false; //mayby not this methodes job to deal with this maybey distch this
		//}
		//check if there is mho in the way
		if (baord[target.x][target.y].compare('M')) { //moho in the way
			//check if its not moved away or been moved to again
			if (inMovedTo(target) || !inMovedAway(target)) {
				return false; //mhos can not move onto other mhos no matter what
			} else {//if its a mho that hasnt moved
					//move the mho in the way out of the way
				Move(target); //moving the mho
				//recurse and retry the move
				try
				{
					return normalMove(origin, target, sucide); //actally mving this one now, effectivly sarting from the top
				}catch(Exception e) {}
			}
		}
		//if this is not sucide mode and the target is a fence don't move
		else if (!sucide && baord[target.x][target.y].compare('F')) { //checks target for being a fence
			return false; //dont move
		}
		//if its a good place to move, also fence ok because already check if its fence
		else if (baord[target.x][target.y].compare('F') || baord[target.x][target.y].compare('P') || baord[target.x][target.y].compare('T')) {
			//check if its been moved to
			if (!inMovedTo(target)) { //if its not moved too
				movedAway.add(origin); //add to moved away
				movedTo.add(target); // add target to moved too
				retval.add(new Move(origin, target)); //make a new move
				return true; //made a move;
			}
		}
		return false; //return false, howver this should never happen
	}

	public static Type[][] movesToBaord(Type[][] a, Move[] moves) {
		Type[][] newBoard = new Type[a.length][a.length]; //init a new array of the same length not refrnced
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a.length; j++) { //Iterate through all the slots in the array
				newBoard[i][j] = a[i][j]; //this process is to copy without references which sucks
			}
		}
		for (Move i : moves) {
			//only moves if origin in a is a mho
			if (a[i.origin.x][i.origin.y].compare('M')) {
				//change the spot of newBoard to tile
				newBoard[i.origin.x][i.origin.y] = new Type('T');
				//if the target isn't a fence change it to mho
				if (!a[i.move.x][i.move.y].compare('F')) { //if its not a fence, yeah unreadable
					newBoard[i.move.x][i.move.y] = new Type('M'); //add the mho to the new board
				}
			}
		}
		return newBoard;
	}

	static Type[][] moveBoard(Type[][] a, byte difculty) { //makes a new barod using this new code
		Move[] newMoves = genrateMoves(a, difculty);
		Type[][] newBoard = movesToBaord(a, newMoves);
		
		Main.board = newBoard;
		
		return newBoard;
	}
	//helper methods
	//mostly for dealing with moved and board and stuff

	private static boolean inMovedTo(Coordinate a) { //checks if its in moved
		for (Coordinate i : movedTo) {
			if (i.x == a.x && i.y == a.y) {
				return true;
			}
		}
		return false;
	}

	private static boolean inMovedAway(Coordinate a) { //checks if its in movedAway
		for (Coordinate i : movedAway) {
			if (i.x == a.x && i.y == a.y) {
				return true;
			}
		}
		return false;
	}

	private static Coordinate playerLoc() {
		if (isPlayerLegit()) { //checks if there is a player
			return storePlayer; //checking updates player location so just return the player location
		} else {
			return new Coordinate(-1, -1); //retunr a dumb coordiante where nothing is
		}
	}

	private static boolean isPlayerLegit() {

		for (int i = 0; i < baord.length; i++) {
			for (int j = 0; j < baord.length; j++) {//iterate through all them things
				if (baord[i][j].compare('P')) { //is it a player
					storePlayer = new Coordinate(i, j); //store it becuase it wasnt already stored
					return true; //well there is a player so..
				}
			}
		}
		if (storePlayer != null) {
			return true;
		}
		return false; //no player and it isnt already stored
	}
	
}
