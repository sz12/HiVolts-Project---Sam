package hivolts;

public class CreateMap {
	// this is the first iteration
	// completly random genration
	public static Type[][] makeMap() {
		Type[][] baord = new Type[12][12];

		for (int i = 0; i <= 11; i++) {
			for (int j = 0; j <= 11; j++) {
				baord[i][j] = new Type();
				if (i == 0 || i == 11 || j == 11 || j == 0) {
					baord[i][j] = new Type('F');
				}
			}
		}

		// add in some more fences
		for (int i = 0; i < 20; i++) {
			boolean escape = false;
			do {
				int x = randomInRange(10, 1);
				int y = randomInRange(10, 1);
				if (baord[x][y].compare('T')) {
					baord[x][y].setType('F');
					escape = true;
				}
			} while (!escape);
		}

		// add in some mohos
		for (int i = 0; i < 12; i++) {
			boolean escape = false;
			do {
				int x = randomInRange(10, 1);
				int y = randomInRange(10, 1);
				if (baord[x][y].compare('T')) {
					baord[x][y].setType('M');
					escape = true;
				}
			} while (!escape);
		}

		// finally add a player
		{ //keep the boolean in this block
			boolean escape = false;
			do {
				int x = randomInRange(10, 1);
				int y = randomInRange(10, 1);
				if (baord[x][y].compare('T')) {
					baord[x][y].setType('P');
					escape = true;
				}
			} while (!escape);
		}

		return baord;
	}

	private static int randomInRange(int max, int min) {
		int randomNum = min + (int) (Math.random() * ((max - min) + 1));
		return randomNum;
	}
}