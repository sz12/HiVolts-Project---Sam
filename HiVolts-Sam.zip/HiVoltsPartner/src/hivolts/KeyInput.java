package hivolts;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class KeyInput extends KeyAdapter
{
	private int playerX;
	private int playerY;
	
	private Main main;
	
	public KeyInput(Main main)
	{
		this.main = main;
	}
	
	public void keyPressed(KeyEvent e)
	{
		//Re-updates the x and y position (array wise)
		//Runs through the array and finds the player position. 
		int key = e.getKeyCode();
		
		if(key == KeyEvent.VK_ESCAPE)
		{
			System.exit(0);
		}
		
		if(main.checkGame())
		{
			for(int i = 0; i < 12; i ++)
			{
				for(int j = 0; j < 12; j ++)
				{
					if(Main.board[i][j].toChar() == 'P')
					{
						playerX = i;
						playerY = j;
					}
				}
			}
			
			if(key == KeyEvent.VK_Q)
			{
				if(Main.board[playerX -1][playerY -1].compare('F'))
				{}
				else if(Main.board[playerX -1][playerY -1].compare('M'))
				{
					//GameOver
				}
				else
				{
					Main.board[playerX -1][playerY -1].setType('P');
					Main.board[playerX][playerY].setType('T');
				}
				//Pass turn
			}
			else if(key == KeyEvent.VK_W)
			{
				if(Main.board[playerX][playerY -1].compare('F'))
				{}
				else if(Main.board[playerX][playerY -1].compare('M'))
				{
					//GameOver
				}
				else
				{
					Main.board[playerX][playerY -1].setType('P');
					Main.board[playerX][playerY].setType('T');
				}
				//Pass turn
			}
			else if(key == KeyEvent.VK_E)
			{
				if(Main.board[playerX +1][playerY - 1].compare('F'))
				{}
				else if(Main.board[playerX +1][playerY -1].compare('M'))
				{
					//GameOver
				}
				else
				{
					Main.board[playerX +1][playerY - 1].setType('P');
					Main.board[playerX][playerY].setType('T');
				}
				//Pass turn
			}
			else if(key == KeyEvent.VK_A)
			{
				if(Main.board[playerX -1][playerY].compare('F'))
				{}
				else if(Main.board[playerX -1][playerY].compare('M'))
				{
					//GameOver
				}
				else
				{
					Main.board[playerX -1][playerY].setType('P');
					Main.board[playerX][playerY].setType('T');
				}
				//Pass turn
			}
			else if(key == KeyEvent.VK_S)
			{
				//Pass turn
			}
			else if(key == KeyEvent.VK_D)
			{
				if(Main.board[playerX +1][playerY].compare('F'))
				{}
				else if(Main.board[playerX +1][playerY].compare('M'))
				{
					//GameOver
				}
				else
				{
					Main.board[playerX +1][playerY].setType('P');
					Main.board[playerX][playerY].setType('T');
				}
				//Pass turn
			}
			else if(key == KeyEvent.VK_Z)
			{
				if(Main.board[playerX -1][playerY + 1].compare('F'))
				{}
				else if(Main.board[playerX -1][playerY +1].compare('M'))
				{
					//GameOver
				}
				else
				{
					Main.board[playerX -1][playerY + 1].setType('P');
					Main.board[playerX][playerY].setType('T');
				}
				//Pass turn
			}
			else if(key == KeyEvent.VK_X)
			{
				if(Main.board[playerX][playerY + 1].compare('F'))
				{}
				else if(Main.board[playerX][playerY +1].compare('M'))
				{
					//GameOver
				}
				else
				{
					Main.board[playerX][playerY + 1].setType('P');
					Main.board[playerX][playerY].setType('T');
				}
				//Pass turn
			}
			else if(key == KeyEvent.VK_C)
			{
				if(Main.board[playerX +1][playerY +1].compare('F'))
				{}
				else if(Main.board[playerX +1][playerY +1].compare('M'))
				{
					//GameOver
				}
				else
				{
					Main.board[playerX +1][playerY +1].setType('P');
					Main.board[playerX][playerY].setType('T');
				}
				//Pass turn
			}
			
			else if(key == KeyEvent.VK_J)
			{
				while(true)
				{
					//Generates jump position. 
					int randoX = (int)(Math.random() * 11) + 1;
					int randoY = (int)(Math.random() * 11) + 1;
					
					if(Main.board[randoX][randoY].compare('F'))
					{}
					else 
					{
						if(Main.board[randoX][randoY].compare('M'))
						{
							Main.gameOverText = "You landed on a moe :(";
							main.gameOver();
						}
						else
						{
							Main.board[randoX][randoY].setType('P');
							Main.board[playerX][playerY].setType('T');
						}
						
						break;
					}
				}
				//Pass Turn
			}
		}
	}
}
