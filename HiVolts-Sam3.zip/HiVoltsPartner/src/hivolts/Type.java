//Kai
package hivolts;

public class Type {
	private byte type;
	//Constructor
	Type(){
		type = 0;
	}
	Type(byte a){
		type = a;
	}
	Type(char a){
		if(realType(a)){
		byte b = charToByte(a);
		Type c = new Type(b);
		this.type = c.type;
		}
	}
	Type(Type a){
		this.type = a.type;
	}
	
	//set type
	void setType(Type a){
		this.type = a.type;
	}
	void setType(char a){
		if(realType(a)){
			Type b = new Type(a);
			this.type = b.type;
		}
	}
	
	//compare type
	boolean compare(Type a){
		if(a.type == this.type){
			return true;
		}
		return false;
	}
	boolean compare(byte a){
		if(this.type == a){
			return true;
		}
		return false;
	}
	boolean compare(char a){
		if(realType(a)){
			Type b = new Type(a);
			if(this.type == b.type){
				return true;
			}
		}
		return false;
	}
	
	//tostuff
	public String toString(){
		if(this.type == 0){ return "Tile";}
		if(this.type == 1){ return "Fence";}
		if(this.type == 2){ return "Moho";}
		if(this.type == 3){ return "Player";}
		return "sorry this must be a mistake; im not any of the normal ones";//fail value
	}
	public char toChar(){
		if(this.type == 0){ return 'T';}
		if(this.type == 1){ return 'F';}
		if(this.type == 2){ return 'M';}
		if(this.type == 3){ return 'P';}
		return 'x'; //fail value
	}
	public Byte toByte(){
		return this.type;
	}
	/////
	//put a tographicsobeject or wahtever hear for the drawer
	/////
	
	//helpers
	Type byteToType(byte a){
		return(new Type(a));
	}
	Type charTotype(char a){
		return (new Type(a));
	}
	Byte charToByte(char a){
		char b = Character.toLowerCase(a);
		byte retval = 0;
		if(b == 't'){ retval = 0;}
		if(b == 'f'){ retval = 1;}
		if(b == 'm'){ retval = 2;}
		if(b == 'p'){ retval = 3;}
		return retval;
	}
	boolean realType(char a){
		char b = Character.toLowerCase(a);
		if(b == 't'){ return true;}
		if(b == 'f'){ return true;}
		if(b == 'm'){ return true;}
		if(b == 'p'){ return true;}
		return false;
	}
}