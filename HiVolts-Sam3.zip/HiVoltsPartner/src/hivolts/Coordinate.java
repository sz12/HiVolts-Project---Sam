//Kai
package hivolts;

public class Coordinate {
	public int x;
	public int y;
	Coordinate(){
		this.x = 0;
		this.y = 0;
	}
	Coordinate(int xIn, int yIn){
		this.x = xIn;
		this.y = yIn;
	}
}