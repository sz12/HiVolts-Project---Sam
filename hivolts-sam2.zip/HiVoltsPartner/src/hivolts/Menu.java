//Samuel
package hivolts;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;

import spritesheet.SpriteSheet;

public class Menu extends MouseAdapter
{
	private Main main;
	
	private BufferedImage[][] title = new BufferedImage[8][4];
	
	private BufferedImage fence;
	
	private Color menuButton1 = Color.WHITE;
	private Color menuButton2 = Color.WHITE;
	private Color menuButton3 = Color.WHITE;
	private Color menuButton4 = Color.WHITE;
	
	public Menu(Main main)
	{
		this.main = main;
		
		SpriteSheet ss1 = new SpriteSheet(main.getLogoSheet());
		SpriteSheet ss2 = new SpriteSheet(main.getSpriteSheet());
		
		fence = ss2.grabImage(1, 1, 60, 60);
		
		for(int i = 0; i < 8; i ++)
		{
			for(int j = 0; j < 4; j ++)
			{
				title[i][j] = ss1.grabImage(i + 1, j + 1, 32, 32);
			}
		}
	}
	
	public boolean mouseOver(int mx, int my, int x, int y, int width, int height)
	{
		if(mx > x && mx < x + width)
		{
			if(my > y && my < y + height)
			{
				return true;
			}else
				return false;
		}else
			return false;
	}
	
	public void mousePressed(MouseEvent e)
	{
		int mx = e.getX();
		int my = e.getY();
		
		if(main.checkMenu())
		{
			if(mouseOver(mx, my, 255, 250, 200, 64))
			{				
				main.startGame();
			}
			
			else if(mouseOver(mx, my, 255, 350, 200, 64))
			{
				main.help();
				
				System.out.println(main.checkHelp());
			}
			
			else if(mouseOver(mx, my, 255, 450, 200, 64))
			{
				System.exit(0);
			}
		}
		
		//Back button in help menu
		else if(main.checkHelp())
		{
			if(mouseOver(mx, my, 270, 580, 200, 64))
			{
				main.returnToMenu();
			}
		}
		
		else if(main.checkGameOver() || main.checkGameWin())
		{
			if(mouseOver(mx, my, 275, 530, 200, 64))
			{
				main.returnToMenu();
			}
		}
		
	}

	public void mouseReleased(MouseEvent e)
	{
		
	}
	
	public void mouseMoved(MouseEvent e)
	{
		int mx = e.getX();
		int my = e.getY();
		
		if(main.checkMenu())
		{
			if(mouseOver(mx, my, 255, 250, 200, 64))
			{
				menuButton1 = Color.BLUE;
			}
			else
			{
				menuButton1 = Color.WHITE;
			}
			
			if(mouseOver(mx, my, 255, 350, 200, 64))
			{
				menuButton2 = Color.GREEN;
			}
			else
			{
				menuButton2 = Color.WHITE;
			}
			
			if(mouseOver(mx, my, 255, 450, 200, 64))
			{
				menuButton3 = Color.RED;
			}
			else
			{
				menuButton3 = Color.WHITE;
			}
			
		}
		if(main.checkHelp())
		{
			if(mouseOver(mx, my, 270, 580, 200, 64))
			{
				menuButton4 = Color.YELLOW;
			}
			else
			{
				menuButton4 = Color.WHITE;
			}
		}
		if(main.checkGameOver() || main.checkGameWin())
		{
			if(mouseOver(mx, my, 275, 530, 200, 64))
			{
				menuButton4 = Color.YELLOW;
			}
			else
			{
				menuButton4 = Color.WHITE;
			}
		}
	}
	
	public void render(Graphics g)
	{
		if(main.checkMenu())
		{
			Font fnt1 = new Font("arial", 1, 50);
			Font fnt2 = new Font("arial", 1, 30);
			Font fnt3 = new Font("arial", 1, 15);
			
			for(int i = 0; i < 8; i ++)
			{
				for(int j = 0; j < 4; j ++)
				{
					g.drawImage(title[i][j], (32 * i) + 250, (32 * j) + 100, null);
				}
			}
			
			for(int i = 0; i < 12; i ++)
			{
				for(int j = 0; j < 12; j ++)
				{
					if(i == 0 || i == 11 || j == 0 || j == 11)
					{
						g.drawImage(fence, i * 60, j * 60, null);
					}
				}
			}
			
			g.setFont(fnt3);
			g.setColor(Color.WHITE);
			g.drawString("Updates: " + Main.globalupdates + "", 75, 650);
			
			
			g.setFont(fnt2);
			g.setColor(menuButton1);
			g.drawString("Play", 325, 290);
			g.drawRect(255, 250, 200, 64);
			g.setColor(Color.WHITE);
			
			g.setColor(menuButton2);
			g.drawString("Help", 325, 390);
			g.drawRect(255, 350, 200, 64);
			g.setColor(Color.WHITE);
			
			g.setColor(menuButton3);
			g.drawString("Quit", 325, 490);
			g.drawRect(255, 450, 200, 64);
			g.setColor(Color.WHITE);
		}
		else if(main.checkHelp())
		{
			Font fnt1 = new Font("arial", 1, 50);
			Font fnt2 = new Font("arial", 1, 30);
			Font fnt3 = new Font("arial", 1, 15);
			
			for(int i = 0; i < 12; i ++)
			{
				for(int j = 0; j < 12; j ++)
				{
					if(i == 0 || i == 11 || j == 0 || j == 11)
					{
						g.drawImage(fence, i * 60, j * 60, null);
					}
				}
			}
			
			g.setFont(fnt3);
			g.setColor(Color.WHITE);
			g.drawString("Updates: " + Main.globalupdates + "", 75, 650);
			
			g.setColor(Color.WHITE);

			g.setFont(fnt1);
			g.drawString("Help", 325, 125);
			
			g.setFont(fnt2);
			g.drawString("Use QWESDZXC to move around", 150, 200);
			g.drawString("Use J to jump", 275, 250);
			g.drawString("Press 'esc'. to quit any time", 175, 300);
			
			g.drawString("Make all of the moes run into electric", 100, 400);
			g.drawString("fences and you win!", 230, 450);
			
			g.setColor(menuButton4);
			g.drawRect(270, 580, 200, 64);
			g.drawString("Back", 335, 620);
		}
		else if(main.checkGameOver())
		{
			Font fnt1 = new Font("arial", 1, 50);
			Font fnt2 = new Font("arial", 1, 30);
			Font fnt3 = new Font("arial", 1, 20);
			
			for(int i = 0; i < 12; i ++)
			{
				for(int j = 0; j < 12; j ++)
				{
					if(i == 0 || i == 11 || j == 0 || j == 11)
					{
						g.drawImage(fence, i * 60, j * 60, null);
					}
				}
			}
			
			g.setFont(fnt3);
			g.setColor(Color.WHITE);
			g.drawString("Updates: " + Main.globalupdates + "", 75, 650);
			
			g.setColor(Color.WHITE);
			g.setFont(fnt1);
			g.drawString("GAME OVER", 225, 125);
			g.setFont(fnt2);
			Main.gameOverText = "You got eaten by a moe :(";
			
			g.drawString(Main.gameOverText, 200, 300);
			
			g.setFont(fnt2);
			g.setColor(menuButton4);
			g.drawRect(275, 530, 200, 64);
			g.drawString("Return", 330, 570);
		}
		else if(main.checkGameWin())
		{
			Font fnt1 = new Font("arial", 1, 50);
			Font fnt2 = new Font("arial", 1, 30);
			Font fnt3 = new Font("arial", 1, 20);
			
			for(int i = 0; i < 12; i ++)
			{
				for(int j = 0; j < 12; j ++)
				{
					if(i == 0 || i == 11 || j == 0 || j == 11)
					{
						g.drawImage(fence, i * 60, j * 60, null);
					}
				}
			}
			
			g.setFont(fnt3);
			g.setColor(Color.WHITE);
			g.drawString("Updates: " + Main.globalupdates + "", 75, 650);
			
			g.setColor(Color.WHITE);
			g.setFont(fnt1);
			g.drawString("GAME COMPLETE", 170, 125);
			
			g.setFont(fnt2);
			Main.gameOverText = "Congrats! You won!";
			
			g.drawString(Main.gameOverText, 230, 300);
			
			g.setFont(fnt2);
			g.setColor(menuButton4);
			g.drawRect(275, 530, 200, 64);
			g.drawString("Return", 330, 570);
		}
	}
}
