//Samuel
package hivolts;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;

import spritesheet.BufferedImageLoader;
import spritesheet.SpriteSheet;

public class Main extends Canvas implements Runnable
{
	public static String gameOverText = "";
	public static int globalupdates;
	public static int globalframes;
	
	public static Type[][] board = new Type[12][12];
	
	private final int height = 730;
	private final int width = 755;
	
	public boolean running = false;
	
	private Window window;
	private Menu menu;
	
	Thread thread = new Thread(this);
	
	private BufferedImage spriteSheet;
	private BufferedImage logo;
	private BufferedImage fence;
	private BufferedImage player;
	private BufferedImage mhoe;
	
	//Stuffs
	public enum STATE
	{
		Menu, 
		Help, 
		Game, 
		GameOver,
		GameWin,
	};
	
	private STATE gameState = STATE.Menu;
	
	public Main()
	{
		BufferedImageLoader loader = new BufferedImageLoader();
		
		try
		{
			spriteSheet = loader.loadImage("/HiVoltzSpriteSheet.png");
			logo = loader.loadImage("/HiVoltsLogo.png");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		//Creates a new window that holds the frame.
		window = new Window(width, height, this);
		menu = new Menu(this);
		
		this.addKeyListener(new KeyInput(this));
		this.addMouseListener(menu);
		this.addMouseMotionListener(menu);
		
		if(gameState == STATE.Game)
		{
			generateBoard();
		}
	}
	
	public synchronized void start()
	{
		if(running == false)
		{
			//Begins the game thread
			running = true;
			thread.start();
			
		}
	}
	
	public synchronized void stop()
	{
		if(running = true)
		{
			try {
				thread.join();
				running = false;
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public void run()
	{
		//System.out.println("hao");
		
		this.requestFocus(); //Makes it so that you don't need to click on screen to use key inputs
		long lastTime = System.nanoTime();
		final double amountOfTicks = 60.0;
		double ns = 1000000000 / amountOfTicks;
		double delta = 0; //Counts time to see whether program is falling behind ticks. Speeds up.
		int updates = 0;
		int frames = 0;
		long timer = System.currentTimeMillis();
		
		while(running) //Game loop
		{
			long now = System.nanoTime();
			delta += (now - lastTime) / ns;
			lastTime = now;
			if(delta >= 1)
			{
				tick(); //Update game
				updates ++;
				delta --;
			}
			
			try
			{
				render();
			}catch(Exception e) {}
			
			frames ++;
				
			if(System.currentTimeMillis() - timer > 1000)
			{
				timer += 1000;
				globalupdates = updates;
				globalframes = frames;
				System.out.println(frames + " " + updates);
				updates = 0;
				frames = 0;
			} 
		}
		
		stop();
	}
	
	public void tick()
	{
		
	}
	
	public void render()
	{
		BufferStrategy bs = this.getBufferStrategy();
		if(bs == null)
		{
			this.createBufferStrategy(3);
			return;
		}
		
		Graphics g = bs.getDrawGraphics();
		g.setColor(Color.BLACK);
		g.fillRect(0, 0, width, height);
		
		if(gameState == STATE.Game)
		{
			printBoard(board, g);
		}
		
		if(gameState == STATE.Menu || gameState == STATE.Help || gameState == STATE.GameOver || gameState == STATE.GameWin)
		{
			menu.render(g);
		}
		
		bs.show(); //Puts the buffer strategy in action
		g.dispose(); //Gets rid of all unnesecary graphics. 
	}
	
	public static void main(String[] args)
	{
		new Main();
	}
	
	public void printBoard(Type[][] a, Graphics g)
	{
		SpriteSheet ss = new SpriteSheet(getSpriteSheet());
		
		fence = ss.grabImage(1, 1, 60, 60);
		player = ss.grabImage(3, 1, 60, 60);
		mhoe = ss.grabImage(5, 1, 60, 60);
		for(int i = 0; i < board.length; i ++)
		{
			for(int j = 0; j < board.length; j ++)
			{
				if(board[i][j].toChar() == 'F')
				{
					g.drawImage(fence, (i) * 60, (j) * 60, null);
				}
				else if(board[i][j].toChar() == 'M')
				{
					g.drawImage(mhoe, (i) * 60, (j) * 60, null);
				}
				else if(board[i][j].toChar() == 'T')
				{}
				else
				{
					g.drawImage(player, (i) * 60, (j) * 60, null);
				}
				//g.drawString(board[i][j].toChar() + "", (i) * 60, (j) * 60);
				//System.out.print();
			}
		}
	}
	
	public void startGame()
	{
		generateBoard();
		gameState = STATE.Game;
	}
	
	public void endGame()
	{
		gameState = STATE.GameOver;
	}
	
	public void generateBoard()
	{
		//makes a board
		board = CreateMap.makeMap();
	}
	
	public BufferedImage getSpriteSheet()
	{
		return spriteSheet;
	}
	
	public BufferedImage getLogoSheet()
	{
		return logo;
	}
	
	////////////////////////////////////////////
	public boolean checkGame()
	{
		if(gameState == STATE.Game)
			return true;
		else 
			return false;
	}
	
	public void returnToMenu()
	{
		gameState = STATE.Menu;
	}
	public boolean checkMenu()
	{
		if(gameState == STATE.Menu)
			return true;
		else 
			return false;
	}
	
	public void help()
	{
		gameState = STATE.Help;
	}
	public boolean checkHelp()
	{
		if(gameState == STATE.Help)
			return true;
		else 
			return false;
	}
	
	public void gameOver()
	{
		gameState = STATE.GameOver;
	}
	public boolean checkGameOver()
	{
		if(gameState == STATE.GameOver)
			return true;
		else
			return false;
	}
	
	public void gameWin()
	{
		gameState = STATE.GameWin;
	}
	public boolean checkGameWin()
	{
		if(gameState == STATE.GameWin)
			return true;
		else
			return false;
	}
}