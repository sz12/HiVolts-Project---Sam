//Kai
package hivolts;

import java.util.ArrayList;

public class MoeAI {
	private static Type[][] baord;
	private static ArrayList<Coordinate> moved = new ArrayList<Coordinate>();
	private static Coordinate oldPlayer;

	public static Type[][] makeMoves(Type[][] a) {
		// rest moved
		moved = new ArrayList<Coordinate>();
		// set baord to the old board
		baord = a;

		// itrate through all types on board if its unmoved and moho, call moveCoordinate
		for (int i = 0; i < baord.length; i++) {
			for (int j = 0; j < baord[0].length; j++) {
				if (baord[i][j].compare('M') && !inMoved(new Coordinate(i, j))) {
					moveCoordinate(new Coordinate(i, j));
				}
			}
		}

		return baord;
	}

	private static void moveCoordinate(Coordinate a) {

		// check if player exists if he dont do anything
		if (isPlayerLegit()) {
			if (isVirticleOrHorizontal(playerLoc(), a)) { // is virticle of horizontal?
				moveVirticleOrHorizontal(a);// just calls the other thing
			} else {
				if (moveDiagonal(a))
					; //break;
				else if (moveOrthogonal(a))
					;
				else if (sucideDiagonal(a))
					;
				else if (sucideOrthogonal(a))
					;
				moved.add(a);
			}
		}
	}

	private static boolean moveDiagonal(Coordinate a) {
		//check if it should move daignally
		if (isDiagonal(a, playerLoc())) {
			//player is up right
			if (a.x < playerLoc().x && a.y < playerLoc().x) {
				return moveBetween(a, new Coordinate(a.x + 1, a.y + 1));
			}
			//down right
			else if (a.x > playerLoc().x && a.y < playerLoc().x) {
				return moveBetween(a, new Coordinate(a.x - 1, a.y + 1));
			}
			//down left
			else if (a.x > playerLoc().x && a.y > playerLoc().x) {
				return moveBetween(a, new Coordinate(a.x - 1, a.y - 1));
			}
			//up left
			else if (a.x < playerLoc().x && a.y > playerLoc().x) {
				return moveBetween(a, new Coordinate(a.x + 1, a.y - 1));
			}
		}
		return false;
	}

	private static boolean sucideDiagonal(Coordinate a) {
		//check if it should move daignally
		if (isDiagonal(a, playerLoc())) {
			//player is up right
			if (a.x < playerLoc().x && a.y < playerLoc().x) {
				return sucideBetween(a, new Coordinate(a.x + 1, a.y + 1));
			}
			//down right
			else if (a.x > playerLoc().x && a.y < playerLoc().x) {
				return sucideBetween(a, new Coordinate(a.x - 1, a.y + 1));
			}
			//down left
			else if (a.x > playerLoc().x && a.y > playerLoc().x) {
				return sucideBetween(a, new Coordinate(a.x - 1, a.y - 1));
			}
			//up left
			else if (a.x < playerLoc().x && a.y > playerLoc().x) {
				return sucideBetween(a, new Coordinate(a.x + 1, a.y - 1));
			}
		}
		return false;
	}

	private static boolean moveOrthogonal(Coordinate a) {
		if (Math.abs(a.x - playerLoc().x) > Math.abs(a.y - playerLoc().y)) { //move horizontal
			if (a.x > playerLoc().x) { //move left
				return moveBetween(a, new Coordinate(a.x - 1, a.y));
			} else {//move right
				return moveBetween(a, new Coordinate(a.x + 1, a.y));
			}
		} else if (Math.abs(a.x - playerLoc().x) < Math.abs(a.y - playerLoc().y)) {//move virticle
			if (a.y > playerLoc().y) { //move down
				return moveBetween(a, new Coordinate(a.x, a.y - 1));
			} else { //move up
				return moveBetween(a, new Coordinate(a.x, a.y + 1));
			}
		}
		return false;
	}

	private static boolean sucideOrthogonal(Coordinate a) {
		if (Math.abs(a.x - playerLoc().x) > Math.abs(a.y - playerLoc().y)) { //move horizontal
			if (a.x > playerLoc().x) { //move left
				return sucideBetween(a, new Coordinate(a.x - 1, a.y));
			} else {//move right
				return sucideBetween(a, new Coordinate(a.x + 1, a.y));
			}
		} else if (Math.abs(a.x - playerLoc().x) < Math.abs(a.y - playerLoc().y)) {//move virticle
			if (a.y > playerLoc().y) { //move down
				return sucideBetween(a, new Coordinate(a.x, a.y - 1));
			} else { //move up
				return sucideBetween(a, new Coordinate(a.x, a.y + 1));
			}
		}
		return false;
	}

	private static boolean moveBetween(Coordinate a, Coordinate b) {
		//check if a is in moved
		if (!inMoved(a)) { //if it is just return false
			if (safeMove(b)) { //is this something to move onto
				//set a to tile
				baord[a.x][a.y] = new Type('T');
				//set b to moho
				baord[b.x][b.y] = new Type('M');
				//add b to moved
				moved.add(b);
				//return true;
				return true; //because its moved
			} else if (baord[b.x][b.y].compare('M')) { //if its moho
				if (!inMoved(b)) { //if the moho has moved
					moveCoordinate(b); //move that first
					return moveBetween(a, b); //try moving this again
				}
			}
		}
		return false;
	}

	private static boolean sucideBetween(Coordinate a, Coordinate b) {
		//check if a is in moved
		if (!inMoved(a)){ //if it is just return false
			if (legalMove(b)) { //is this something to move onto
				//set a to tile
				baord[a.x][a.y] = new Type('T');
				//set b to moho
				if(!baord[b.x][b.y].compare('F')){
				baord[b.x][b.y] = new Type('M');
				//add b to moved
				moved.add(b);
				}
				//return true;
				return true; //because its moved
			}
			else if(baord[b.x][b.y].compare('M')){ //if its moho
				if(!inMoved(b)){ //if the moho has moved
					moveCoordinate(b); //move that first
					return moveBetween(a,b); //try moving this again
				}
			}
		}
		return false;
	}

	private static void moveVirticleOrHorizontal(Coordinate a) {
		if (a.x == playerLoc().x) { // is the moho virticle
			moveVirticle(a);
		}
		if (a.y == playerLoc().y) { // is the moho horizontal? do all that stuff above but for x
			moveHorizontal(a);
		}
	}

	private static void moveVirticle(Coordinate a) {
		if (a.y > playerLoc().y) { // moving down
			if (baord[a.x][a.y - 1].compare('M')) { // is it a moho??
				if (!inMoved(new Coordinate(a.x, a.y - 1))) { // has that moho moved if it hasnt move it and then countinue
					moveCoordinate(new Coordinate(a.x, a.y - 1));

					// make a tile
					baord[a.x][a.y] = new Type('T');
					// make the next space moved and moho
					baord[a.x][a.y - 1] = new Type('M');
					moved.add(new Coordinate(a.x, a.y - 1));
				} else { // moho has moved make this square into a tile no need to add it to moved the other moho has already moved
					baord[a.x][a.y] = new Type('T');
				}
			} else {// its not a moho set a to tile, shoudnt be in moved already
				baord[a.x][a.y] = new Type('T');

				if (!baord[a.x][a.y - 1].compare('F')) {
					// if its not a fence set it to moho and add to moved
					baord[a.x][a.y - 1] = new Type('M');
					moved.add(new Coordinate(a.x, a.y - 1));
				}
			}
		}
		if (a.y < playerLoc().y) { // moving up
			if (baord[a.x][a.y + 1].compare('M')) { // is it a moho??
				if (!inMoved(new Coordinate(a.x, a.y + 1))) { // has that moho moved? if it hasnt move it and then countinuce
					moveCoordinate(new Coordinate(a.x, a.y + 1));
					// set a to tile
					baord[a.x][a.y] = new Type('T');
					// make the next space moved and moho
					baord[a.x][a.y + 1] = new Type('M');
					moved.add(new Coordinate(a.x, a.y + 1));
				} else { // moho has moved make this square into a tile need to set it to moved
					baord[a.x][a.y] = new Type('T');
					moved.add(new Coordinate(a.x, a.y + 1));
				}
			} else {// its not a moho set a to tile, shoudnt be in moved already
				baord[a.x][a.y] = new Type('T');

				if (!baord[a.x][a.y + 1].compare('F')) { // if its not a fence
					// set it to moho and add to moved
					baord[a.x][a.y + 1] = new Type('M');
					moved.add(new Coordinate(a.x, a.y + 1));
				}
			}
		}
	}

	private static void moveHorizontal(Coordinate a) {
		if (a.x < playerLoc().x) { // moving right
			if (baord[a.x + 1][a.y].compare('M')) { // is it a moho??
				if (!inMoved(new Coordinate(a.x + 1, a.y))) { // has that moho moved if it hasnt move it and then countinue
					moveCoordinate(new Coordinate(a.x + 1, a.y));

					// make a tile
					baord[a.x][a.y] = new Type('T');
					// make the next space moved and moho
					baord[a.x + 1][a.y] = new Type('M');
					moved.add(new Coordinate(a.x, a.y - 1));
				} else { // moho has moved make this square into a tile no need to add it to moved the other moho has already moved
					baord[a.x][a.y] = new Type('T');
				}
			} else {// its not a moho set a to tile, shoudnt be in moved already
				baord[a.x][a.y] = new Type('T');

				if (!baord[a.x + 1][a.y].compare('F')) { // if its not a fence set it to moho and add to moved
					baord[a.x + 1][a.y] = new Type('M');
					moved.add(new Coordinate(a.x + 1, a.y));
				}
			}
		}
		if (a.x > playerLoc().x) { // moving left
			if (baord[a.x - 1][a.y].compare('M')) { // is it a moho??
				if (!inMoved(new Coordinate(a.x - 1, a.y))) { // has that moho moved? if it hasnt move it and then countinuce
					moveCoordinate(new Coordinate(a.x - 1, a.y));
					// set a to tile
					baord[a.x][a.y] = new Type('T');
					// make the next space moved and moho
					baord[a.x - 1][a.y] = new Type('M');
					moved.add(new Coordinate(a.x, a.y + 1));
				} else { // moho has moved make this square into a tile need to set it to moved
					baord[a.x][a.y] = new Type('T');
					moved.add(new Coordinate(a.x - 1, a.y));
				}
			} else {// its not a moho set a to tile, shoudnt be in moved already
				baord[a.x][a.y] = new Type('T');

				if (!baord[a.x - 1][a.y].compare('F')) { // if its not a fence
					// set it to moho and add to moved
					baord[a.x - 1][a.y] = new Type('M');
					moved.add(new Coordinate(a.x - 1, a.y));
				}
			}
		}
	}

	// methodes not directly controlling movment, helpers

	private static Coordinate playerLoc() {
		if (oldPlayer != null) {
			return oldPlayer;
		}
		for (int i = 0; i <= 11; i++) {
			for (int j = 0; j <= 11; j++) {
				if (baord[i][j].compare('P')) {
					oldPlayer = new Coordinate(i, j);
					return new Coordinate(i, j);
				}
			}
		}
		return new Coordinate(-1, -1);
	}

	private static boolean isPlayerLegit() {
		for (int i = 0; i <= 11; i++) {
			for (int j = 0; j <= 11; j++) {
				if (baord[i][j].compare('P')) {
					oldPlayer = new Coordinate(i, j);
					return true;
				}
			}
		}
		if (oldPlayer != null) {
			return true;
		}
		return false;
	}

	private static boolean isVirticleOrHorizontal(Coordinate a, Coordinate b) {
		if (a.x == b.x) { // check horizontal
			return true;
		}
		if (a.y == b.y) {
			return true; // check virticle
		}
		return false;
	}

	private static boolean isDiagonal(Coordinate a, Coordinate b) {
		//kai's Diagonal
		int z = a.x - b.x; //z diffrence of x and y
		if (a.y - b.y == z || a.y - b.y == -z) {
			return true;
		}
		return (false); //diffrence in y's needs to be z or negative z
	}

	private static boolean inMoved(Coordinate a) {
		for (Coordinate i : moved) {
			if (i.x == a.x && i.y == a.y) {
				return true;
			}
		}
		return false;
	}

	private static boolean safeMove(Coordinate b) {
		if (baord[b.x][b.y].compare('T') || baord[b.x][b.y].compare('P')) {
			return true;
		}
		return false;
	}

	private static boolean legalMove(Coordinate b) {
		if (!baord[b.x][b.y].compare('M')) {
			return true;
		}
		return false;
	}
}