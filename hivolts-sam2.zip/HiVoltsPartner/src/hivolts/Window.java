//Samuel
package hivolts;

import java.awt.Dimension;

import javax.swing.JFrame;

public class Window
{
	public Window(int height, int width, Main main)
	{
		JFrame frame = new JFrame();
		
		frame.setMaximumSize(new Dimension(width, height));
		frame.setPreferredSize(new Dimension(width, height));
		frame.setMinimumSize(new Dimension(width, height));
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);
		
		frame.add(main);
		
		frame.setVisible(true);
		main.start(); //Start of the game!
		//System.out.println("started");
	}
}
